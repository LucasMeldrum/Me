#ifndef TOWER_DECORATOR_UTILITY_H
#define TOWER_DECORATOR_UTILITY_H

#include "Tower.h" // for Tower*

void applyDecorator(Tower*& tower, const std::string& upgradeType);

#endif
