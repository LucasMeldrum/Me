#ifndef STRONGCRITTER_H
#define STRONGCRITTER_H

#include "Critter.h"

class StrongCritter : public Critter {
public:
    StrongCritter(Map* m, int startX, int startY);
};

#endif // STRONGCRITTER_H
