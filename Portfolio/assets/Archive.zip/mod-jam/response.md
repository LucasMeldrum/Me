# Mod-Jam Response
For this mod-jam I decided I want to focus on the design aspects, the visuals/sound, the experience and what was modified. Not looking at the code.

## Ashmitha Kanagiah
> https://ashmyytaa.github.io/cart253/jams/mod-jam/ 
>
> https://github.com/ashmyytaa/cart253/tree/main/jams/mod-jam  

My experience with this mod jam was very nice and kind of relaxing? Initially, the concepts are the same as the original frogfrogfrog but I noticed as I was playing it is a lot slower. Not sure if this was done with intent but I liked it. Playing slower allowed more time to see everything else going on: the waves, the frog's eyes following the mouse, the change in color as the progress bar fills up and the rapidly increasing amount of fish! I think my favorite part was the waves and how artistic it really looked with the silly fish emojis. I also really liked the obvious ending of the gold mine, it really made me jump and was worth taking the time to catch all those flies. Great job!

## Haolei Ma
> https://mmmcarter.github.io/CART253-Fall-2025-/topics/mod-jam
>
> https://github.com/MmmCarter/CART253-Fall-2025-/tree/main/topics/mod-jam

This was a nice simple take on the frogfrogfrog game! My favorite types of games are combo games and this really made me feel like I was playing one. My first playthrough I got every fly in a row (master at the game, I know) and it felt very rewarding going on that great combo and winning quickly. I played the game again just to see the "god frog" mentioned in the instructions (very nice idea having instructions by the way helped with controls and gameplay) and was very nicely surprised with the HUGE tongue. One thing I also enjoyed was the flies' design and how they moved and changed sizes. It's a simple change but also makes the game dynamic and feels different after catching every fly. Finally, the sounds really gave me a laugh the first time. The laugh when missing a fly caught me off guard and made for a laugh out loud moment!

## Joyce Angelina Lam
> https://ajoycel.github.io/cart253-2025/mod_jam/
>
> https://github.com/AJoyceL/cart253-2025/tree/main/mod_jam

I really like how different this is from the frogfrogfrog game yet has very similar mechanics. The idea of using a bat that flies to go grab the flies and comes back while there being obstacles (bad flies and birds in the way) makes it so it feels like a completely different idea! The sounds, visual background and different sprites really combine together to make a fun enjoyable experience that isn't too easy but not too challenging either. I also like that you can lose/win the game based on if you eat enough flies within the time limit. It is also very cool how the moon is going up as the timer is decreasing putting a little presure on the player as they eat the flies needing to eat enough before they run out of time! My favorite part is definitely the sound and how they made me feel while playing. It was relaxing and retro in a way with the eating noise with the music in the background for me and made for a fun time! Great job.
